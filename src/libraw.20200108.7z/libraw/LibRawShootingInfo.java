/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawShootingInfo extends Structure {
//  typedef struct
//  {
//    short DriveMode;
//    short FocusMode;
//    short MeteringMode;
//    short AFPoint;
//    short ExposureMode;
//    short ImageStabilization;
//    char BodySerial[64];
//    char InternalBodySerial[64]; /* this may be PCB or sensor serial, depends on make/model*/
//  } libraw_shootinginfo_t;

    public short DriveMode;
    public short FocusMode;
    public short MeteringMode;
    public short AFPoint;
    public short ExposureMode;
    public short ImageStabilization;
    public byte[] BodySerial = new byte[64];
    public byte[] InternalBodySerial = new byte[64]; /* this may be PCB or sensor serial, depends on make/model*/

}
