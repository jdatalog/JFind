/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawImgOther extends Structure {
//  typedef struct
//  {
//    float iso_speed;
//    float shutter;
//    float aperture;
//    float focal_len;
//    time_t timestamp;
//    unsigned shot_order;
//    unsigned gpsdata[32];
//    libraw_gps_info_t parsed_gps;
//    char desc[512], artist[64];
//    float FlashEC;
//    float FlashGN;
//    float CameraTemperature;
//    float SensorTemperature;
//    float SensorTemperature2;
//    float LensTemperature;
//    float AmbientTemperature;
//    float BatteryTemperature;
//    float exifAmbientTemperature;
//    float exifHumidity;
//    float exifPressure;
//    float exifWaterDepth;
//    float exifAcceleration;
//    float exifCameraElevationAngle;
//    float real_ISO;
//  } libraw_imgother_t;  typedef struct

    public float iso_speed;
    public float shutter;
    public float aperture;
    public float focal_len;
    public long timestamp;
    public int shot_order;
    public int[] gpsdata = new int[32];
    public LibRawGpsInfo parsed_gps;
    public byte[] desc = new byte[512];
    public byte[] artist = new byte[64];
    public float FlashEC;
    public float FlashGN;
    public float CameraTemperature;
    public float SensorTemperature;
    public float SensorTemperature2;
    public float LensTemperature;
    public float AmbientTemperature;
    public float BatteryTemperature;
    public float exifAmbientTemperature;
    public float exifHumidity;
    public float exifPressure;
    public float exifWaterDepth;
    public float exifAcceleration;
    public float exifCameraElevationAngle;
    public float real_ISO;

    public float getIsoSpeed() {
        return iso_speed;
    }

    public float getShutterSpeed() {
        return shutter;
    }

    public float getAperture() {
        return aperture;
    }

    public float getFocalLen() {
        return focal_len;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public int getShot_order() {
        return shot_order;
    }

    public int[] getGpsdata() {
        return gpsdata;
    }

    public LibRawGpsInfo getParsed_gps() {
        return parsed_gps;
    }

    public byte[] getDesc() {
        return desc;
    }

    public byte[] getArtist() {
        return artist;
    }

    public float getFlashEC() {
        return FlashEC;
    }

    public float getFlashGN() {
        return FlashGN;
    }

    public float getCameraTemperature() {
        return CameraTemperature;
    }

    public float getSensorTemperature() {
        return SensorTemperature;
    }

    public float getSensorTemperature2() {
        return SensorTemperature2;
    }

    public float getLensTemperature() {
        return LensTemperature;
    }

    public float getAmbientTemperature() {
        return AmbientTemperature;
    }

    public float getBatteryTemperature() {
        return BatteryTemperature;
    }

    public float getExifAmbientTemperature() {
        return exifAmbientTemperature;
    }

    public float getExifHumidity() {
        return exifHumidity;
    }

    public float getExifPressure() {
        return exifPressure;
    }

    public float getExifWaterDepth() {
        return exifWaterDepth;
    }

    public float getExifAcceleration() {
        return exifAcceleration;
    }

    public float getExifCameraElevationAngle() {
        return exifCameraElevationAngle;
    }

    public float getReal_ISO() {
        return real_ISO;
    }

}
