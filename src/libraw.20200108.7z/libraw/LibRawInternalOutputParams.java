/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawInternalOutputParams extends Structure {
//  typedef struct
//  {
//    unsigned mix_green;
//    unsigned raw_color;
//    unsigned zero_is_bad;
//    ushort shrink;
//    ushort fuji_width;
//  } libraw_internal_output_params_t;

    public int mix_green;
    public int raw_color;
    public int zero_is_bad;
    public short shrink;
    public short fuji_width;
}
