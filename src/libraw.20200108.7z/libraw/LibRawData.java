/*
  Copyright (c) 2009 Harri Kaimio

  This file is part of Photovault.

  Photovault is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  Photovault is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Photovault; if not, write to the Free Software Foundation,
  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 */
package libraw;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.ShortByReference;

/**
 * Java wrapper for libraw structure libraw_data_t
 *
 * @author Harri Kaimio
 * @since 0.6.0
 */
public class LibRawData extends Structure {

//   typedef struct {
//     ushort (*image)[4];
//     libraw_image_sizes_t sizes;
//    libraw_iparams_t idata;
//    libraw_lensinfo_t lens;
//    libraw_makernotes_t makernotes;
//    libraw_shootinginfo_t shootinginfo;
//    libraw_output_params_t params;
//    unsigned int progress_flags;
//    unsigned int process_warnings;
//    libraw_colordata_t color;
//    libraw_imgother_t other;
//    libraw_thumbnail_t thumbnail;
//    libraw_rawdata_t rawdata;
//    void *parent_class;
//  } libraw_data_t;
    public ShortByReference image;    
//    public ShortByReference[] image = new ShortByReference[4];    
    public LibRawImageSizes sizes;
    public LibRawIParams idata;
    public LibRawLensInfo lens;
    public LibRawMakerNotesLens makernotes;
    public LibRawShootingInfo shootinginfo;
    public LibRawOutputParams params;
    public int progress_flags;
    public int process_warnings;
    public LibRawColorData color;
    public LibRawImgOther other;
    public LibRawThumbnail thumbnail;
    public LibRawRawData rawdata;
    public Pointer parent_class;

    public LibRawData() {
        super();
        this.write();
    }

}
