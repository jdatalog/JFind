/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawMakerNotesLens extends Structure {
//  typedef struct
//  {
//    unsigned long long LensID;
//    char Lens[128];
//    ushort LensFormat; /* to characterize the image circle the lens covers */
//    ushort LensMount;  /* 'male', lens itself */
//    unsigned long long CamID;
//    ushort CameraFormat; /* some of the sensor formats */
//    ushort CameraMount;  /* 'female', body throat */
//    char body[64];
//    short FocalType; /* -1/0 is unknown; 1 is fixed focal; 2 is zoom */
//    char LensFeatures_pre[16], LensFeatures_suf[16];
//    float MinFocal, MaxFocal;
//    float MaxAp4MinFocal, MaxAp4MaxFocal, MinAp4MinFocal, MinAp4MaxFocal;
//    float MaxAp, MinAp;
//    float CurFocal, CurAp;
//    float MaxAp4CurFocal, MinAp4CurFocal;
//    float MinFocusDistance;
//    float FocusRangeIndex;
//    float LensFStops;
//    unsigned long long TeleconverterID;
//    char Teleconverter[128];
//    unsigned long long AdapterID;
//    char Adapter[128];
//    unsigned long long AttachmentID;
//    char Attachment[128];
//    ushort CanonFocalUnits;
//    float FocalLengthIn35mmFormat;
//  } libraw_makernotes_lens_t;

    public long LensID;
    public byte[] Lens = new byte[128];
    public short LensFormat;
    /* to characterize the image circle the lens covers */
    public short LensMount;
    /* 'male', lens itself */
    public long CamID;
    public short CameraFormat;
    /* some of the sensor formats */
    public short CameraMount;
    /* 'female', body throat */
    public byte[] body = new byte[64];
    public short FocalType;
    /* -1/0 is unknown; 1 is fixed focal; 2 is zoom */
    public byte[] LensFeatures_pre = new byte[16];
    public byte[] LensFeatures_suf = new byte[16];
    public float MinFocal, MaxFocal;
    public float MaxAp4MinFocal, MaxAp4MaxFocal, MinAp4MinFocal, MinAp4MaxFocal;
    public float MaxAp, MinAp;
    public float CurFocal, CurAp;
    public float MaxAp4CurFocal, MinAp4CurFocal;
    public float MinFocusDistance;
    public float FocusRangeIndex;
    public float LensFStops;
    public long TeleconverterID;
    public byte[] Teleconverter = new byte[128];
    public long AdapterID;
    public byte[] Adapter = new byte[128];
    public long AttachmentID;
    public byte[] Attachment = new byte[128];
    public short CanonFocalUnits;
    public float FocalLengthIn35mmFormat;
}
