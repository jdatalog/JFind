/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawGpsInfo extends Structure  {
//  typedef struct
//  {
//    float latitude[3];     /* Deg,min,sec */
//    float longtitude[3];   /* Deg,min,sec */
//    float gpstimestamp[3]; /* Deg,min,sec */
//    float altitude;
//    char altref, latref, longref, gpsstatus;
//    char gpsparsed;
//  } libraw_gps_info_t;

    public float[] latitude = new float[3];     /* Deg,min,sec */
    public float[] longtitude = new float[3];   /* Deg,min,sec */
    public float[] gpstimestamp = new float[3]; /* Deg,min,sec */
    public float altitude;
    public byte altref;
    public byte latref;
    public byte longref;
    public byte gpsstatus;
    public byte gpsparsed;

}
