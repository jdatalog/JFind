/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawLensInfo extends Structure {
// typedef struct
//  {
//    float MinFocal, MaxFocal, MaxAp4MinFocal, MaxAp4MaxFocal, EXIF_MaxAp;
//    char LensMake[128], Lens[128], LensSerial[128], InternalLensSerial[128];
//    ushort FocalLengthIn35mmFormat;
//    libraw_nikonlens_t nikon;
//    libraw_dnglens_t dng;
//    libraw_makernotes_lens_t makernotes;
//  } libraw_lensinfo_t;

    public float MinFocal;
    public float MaxFocal;
    public float MaxAp4MinFocal;
    public float MaxAp4MaxFocal;
    public float EXIF_MaxAp;

    public byte[] LensMake = new byte[128];
    public byte[] Lens = new byte[128];
    public byte[] LensSerial = new byte[128];
    public byte[] InternalLensSerial = new byte[128];
    public short FocalLengthIn35mmFormat;

    public LibRaw_NikonLens nikon;
    public LibRaw_DngLens dng;
    public LibRawMakerNotesLens makernotes;

}
