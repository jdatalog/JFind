/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRaw_DngLens extends Structure {
//  typedef struct
//  {
//    float MinFocal, MaxFocal, MaxAp4MinFocal, MaxAp4MaxFocal;
//  } libraw_dnglens_t;

    public float MinFocal;
    public float MaxFocal;
    public float MaxAp4MinFocal;
    public float MaxAp4MaxFocal;

}
