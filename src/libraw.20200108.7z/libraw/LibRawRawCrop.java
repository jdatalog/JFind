/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawRawCrop extends Structure {
//  typedef struct
//  {
//    ushort cleft, ctop, cwidth, cheight;
//  } libraw_raw_crop_t;

//    public short cleft;
//    public short ctop;
//    public short cwidth;
//    public short cheight;
//
//    public LibRawRawCrop() {
//         super();
//       this.write();
//    }
    /** C type : ushort */
	public short cleft;
	/** C type : ushort */
	public short ctop;
	/** C type : ushort */
	public short cwidth;
	/** C type : ushort */
	public short cheight;
	public LibRawRawCrop() {
		super();
	}
}
