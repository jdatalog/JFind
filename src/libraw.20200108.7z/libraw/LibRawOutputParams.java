/*
  Copyright (c) 2009 Harri Kaimio

  This file is part of Photovault.

  Photovault is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  Photovault is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Photovault; if not, write to the Free Software Foundation,
  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 */
package libraw;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

/**
 * Used for management of dcraw-compatible calls dcraw_process(),
 * dcraw_ppm_tiff_writer(), dcraw_thumb_writer(), and
 * dcraw_document_mode_processing(). Fields of this structure correspond to
 * command line keys of dcraw.
 *
 * @author Harri Kaimio
 * @since 0.6.0
 */
public class LibRawOutputParams extends Structure {


//  typedef struct
//  {
//    unsigned greybox[4];   /* -A  x1 y1 x2 y2 */
//    unsigned cropbox[4];   /* -B x1 y1 x2 y2 */
//    double aber[4];        /* -C */
//    double gamm[6];        /* -g */
//    float user_mul[4];     /* -r mul0 mul1 mul2 mul3 */
//    unsigned shot_select;  /* -s */
//    float bright;          /* -b */
//    float threshold;       /*  -n */
//    int half_size;         /* -h */
//    int four_color_rgb;    /* -f */
//    int highlight;         /* -H */
//    int use_auto_wb;       /* -a */
//    int use_camera_wb;     /* -w */
//    int use_camera_matrix; /* +M/-M */
//    int output_color;      /* -o */
//    char *output_profile;  /* -o */
//    char *camera_profile;  /* -p */
//    char *bad_pixels;      /* -P */
//    char *dark_frame;      /* -K */
//    int output_bps;        /* -4 */
//    int output_tiff;       /* -T */
//    int user_flip;         /* -t */
//    int user_qual;         /* -q */
//    int user_black;        /* -k */
//    int user_cblack[4];
//    int user_sat; /* -S */
//
//    int med_passes; /* -m */
//    float auto_bright_thr;
//    float adjust_maximum_thr;
//    int no_auto_bright;  /* -W */
//    int use_fuji_rotate; /* -j */
//    int green_matching;
//    /* DCB parameters */
//    int dcb_iterations;
//    int dcb_enhance_fl;
//    int fbdd_noiserd;
//    int exp_correc;
//    float exp_shift;
//    float exp_preser;
//    /* Raw speed */
//    int use_rawspeed;
//    /* DNG SDK */
//    int use_dngsdk;
//    /* Disable Auto-scale */
//    int no_auto_scale;
//    /* Disable intepolation */
//    int no_interpolation;
//    /* int x3f_flags; */
//    /* Sony ARW2 digging mode */
//    /* int sony_arw2_options; */
//    unsigned raw_processing_options;
//    int sony_arw2_posterization_thr;
//    /* Nikon Coolscan */
//    float coolscan_nef_gamma;
//    char p4shot_order[5];
//    /* Custom camera list */
//    char **custom_camera_strings;
//  } libraw_output_params_t;

   /**
     * 4 numbers corresponding to the coordinates (in pixels) of the rectangle
     * that is used to calculate the white balance.
     */
    public int greybox[] = new int[4];   /* -A  x1 y1 x2 y2 */
    public int cropbox[] = new int[4]; /* -B x1 y1 x2 y2 */
    /**
     * dcraw keys: -C Correction of chromatic aberrations; the only specified
     * values are
     * <ul>
     * <li>aber[0], the red multiplier</li>
     * <li>aber[2], the green multiplier. For some formats, it affects RAW data
     * reading, since correction of aberrations changes the output size. </li>
     * </ul>
     */
    public double aber[] = new double[4]; /* -C */
    /**
     * dcraw keys: -g power toe_slope Sets user gamma-curve. Library user should
     * set first two fields of gamm array:
     * <ul>
     * <li>gamm[0] - inverted gamma value)</li>
     * <li>gamm[1] - slope for linear part (so called toe slope). Set to zero
     * for simple power curve.</li>
     * </ul>
     * Remaining 4 values are filled automatically.
     * <p>
     * By default settings for rec. BT.709 are used: power 2.222 (i.e.
     * gamm[0]=1/2.222) and slope 4.5. For sRGB curve use gamm[0]=1/2.4 and
     * gamm[1]=12.92, for linear curve set gamm[0]/gamm[1] to 1.0.
     */
    public double gamm[] = new double[6];        /* -g */
    /**
     * dcraw keys: -r mul0 mul1 mul2 mul3
     * <p>
     * 4 multipliers (r,g,b,g) of the user's white balance.
     */
    public float user_mul[] = new float[4];     /* -r mul0 mul1 mul2 mul3 */
   /**
     * dcraw keys: -s
     * <p>
     * Selection of image number for processing (for formats that contain
     * several RAW images in one file). The multi_out ( -s all) mode should be
     * programmed by the user, since dcraw_process() does not support it.
     */
    public int shot_select;  /* -s */
    /**
     * dcraw keys: -b
     * <p>
     * Brightness (default 1.0).
     */
    public float bright;          /* -b */
    /**
     * dcraw keys: -n
     * <p>
     * Parameter for noise reduction through wavelet denoising.
     */
    public float thereshold;       /*  -n */
    /**
     * dcraw keys: -h
     * <p>
     * Outputs the image in 50% size. For some formats, it affects RAW data
     * reading.
     */
    public int half_size;        /* -h */
    /**
     * dcraw keys: -f
     * <p>
     * Switches on separate interpolations for two green components.
     */
    public int four_color_rgb;   /* -f */
    /**
     * dcraw keys: -H
     * <p>
     * 0-9: Highlight mode (0=clip, 1=unclip, 2=blend, 3+=rebuild).
     */
    public int highlight;         /* -H */
    /**
     * dcraw keys: -a
     * <p>
     * Use automatic white balance obtained after averaging over the entire
     * image.
     */
    public int use_auto_wb;       /* -a */
    /**
     * dcraw keys: -w
     * <p>
     * If possible, use the white balance from the camera.
     */
    public int use_camera_wb;     /* -w */
    /**
     * dcraw keys: +M/-M
     * <p>
     * Use (1)/don't use camera color matrix.
     */
    public int use_camera_matrix; /* +M/-M */
    /**
     * dcraw keys: -o
     * <p>
     * [0-5] Output colorspace (raw, sRGB, Adobe, Wide, ProPhoto, XYZ).
     */
    public int output_color;      /* -o */
    /**
     * dcraw keys: -o filename
     * <p>
     * Path to output profile ICC file (used only if LibRaw compiled with LCMS
     * support)
     */
    public Pointer output_profile;  /* -o */
    /**
     * dcraw keys: -o file
     * <p>
     * Path to input (camera) profile ICC file (or 'embed' for embedded
     * profile). Used only if LCMS support compiled in.
     */
    public Pointer camera_profile;  /* -p */
    /**
     * dcraw keys: -P file
     * <p>
     * to file with bad pixels map (in dcraw format: "column row
     * date-of-pixel-death-in-UNIX-format", one pixel per row).
     */
    public Pointer bad_pixels;      /* -P */
    /**
     * dcraw keys: -K file
     * <p>
     * Path to dark frame file (in 16-bit PGM format)
     */
    public Pointer dark_frame;      /* -K */
    /**
     * dcraw keys: -4
     * <p>
     * 8 bit (default)/16 bit (key -4).
     */
    public int output_bps;        /* -4 */
    /**
     * dcraw keys: -T
     * <p>
     * 0/1: output PPM/TIFF.
     */
    public int output_tiff;       /* -T */
    /**
     * dcraw keys: -t
     * <p>
     * [0-7] Flip image (0=none, 3=180, 5=90CCW, 6=90CW). Default -1, which
     * means taking the corresponding value from RAW.
     * <p>
     * For some formats, affects RAW data reading, e.g., unpacking of thumbnails
     * from Kodak cameras.
     */
    public int user_flip;         /* -t */
    /**
     * dcraw keys: -q
     * <p>
     * 0-3: interpolation quality (0 - linear, 1- VNG, 2 - PPG, 3 - AHD).
     */
    public int user_qual;         /* -q */
    /**
     * dcraw keys: -k
     * <p>
     * User black level.
     */
    public int user_black;        /* -k */
    public int[] user_cblack = new int[4];
    /**
     * dcraw keys: -S
     * <p>
     * Saturation adjustment.
     */
    public int user_sat; /* -S */

    /**
     * dcraw keys: -m
     * <p>
     * Number of median filter passes.
     */
    public int med_passes; /* -m */
    /**
     * dcraw keys:none
     * <p>
     * Portion of clipped pixels when auto brighness increase is used. Default
     * value is 0.01 (1%) for dcraw compatibility. Recommended value for modern
     * low-noise multimegapixel cameras depends on shooting style. Values in
     * 0.001-0.00003 range looks reasonable.
     */
    public float auto_br_thr;
    public float adjust_maximum_thr;
    public int no_auto_bright;  /* -W */
    public int use_fuji_rotate; /* -j */
    public int green_matching;
//    /* DCB parameters */
    public int dcb_iterations;
    public int dcb_enhance_fl;
    public int fbdd_noiserd;
    public int exp_correc;
    public float exp_shift;
    public float exp_preser;
//    /* Raw speed */
    public int use_rawspeed;
//    /* DNG SDK */
    public int use_dngsdk;
//    /* Disable Auto-scale */
    public int no_auto_scale;
//    /* Disable intepolation */
    public int no_interpolation;
//    public int x3f_flags; 
//    /* Sony ARW2 digging mode */
//    public int sony_arw2_options; 
    public int raw_processing_options;
    public int sony_arw2_posterization_thr;
//    /* Nikon Coolscan */
    public float coolscan_nef_gamma;
    public byte[] p4shot_order = new byte[5];
//    /* Custom camera list */
    public Pointer custom_camera_strings;
    
}
