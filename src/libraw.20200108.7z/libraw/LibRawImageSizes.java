/*
  Copyright (c) 2009 Harri Kaimio

  This file is part of Photovault.

  Photovault is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  Photovault is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Photovault; if not, write to the Free Software Foundation,
  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 */
package libraw;

import com.sun.jna.Structure;
import com.sun.jna.ptr.PointerByReference;

/**
 * Java wrapper for libraw structure libraw_image_sizes_t
 *
 * @author Harri Kaimio
 * @since 0.6.0
 */
public class LibRawImageSizes extends Structure {
//  typedef struct
//  {
//    ushort raw_height, raw_width, height, width, top_margin, left_margin;
//    ushort iheight, iwidth;
//    unsigned raw_pitch;
//    double pixel_aspect;
//    int flip;
//    int mask[8][4];
//    libraw_raw_crop_t raw_crop;
//  } libraw_image_sizes_t;
//

    public short raw_height;
    public short raw_width;
    public short height;
    public short width;
    public short top_margin;
    public short left_margin;
    public short iheight;
    public short iwidth;
    public int raw_pitch;
    public double pixel_aspect;
    public int flip;
    public int[] mask = new int[8*4];//    int mask[8][4];
    public LibRawRawCrop raw_crop = null;

    public LibRawImageSizes() {
//        super();
        this.write();
    }

}
