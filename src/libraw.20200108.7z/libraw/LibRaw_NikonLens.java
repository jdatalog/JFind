/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRaw_NikonLens extends Structure {
//  typedef struct
//  {
//    float NikonEffectiveMaxAp;
//    uchar NikonLensIDNumber, NikonLensFStops, NikonMCUVersion, NikonLensType;
//  } libraw_nikonlens_t;

    public float NikonEffectiveMaxAp;
    public byte NikonLensIDNumber;
    public byte NikonLensFStops;
    public byte NikonMCUVersion;
    public byte NikonLensType;

}
