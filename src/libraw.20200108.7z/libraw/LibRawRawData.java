/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraw;

import com.sun.jna.Pointer;
import com.sun.jna.Structure;

/**
 *
 * @author tophe
 */
public class LibRawRawData extends Structure{
//  typedef struct
//  {
//   /* really allocated bitmap */
//    void *raw_alloc;
//    /* alias to single_channel variant */
//    ushort *raw_image;
//    /* alias to 4-channel variant */
//    ushort (*color4_image)[4];
//    /* alias to 3-color variand decoded by RawSpeed */
//    ushort (*color3_image)[3];
//    /* float bayer */
//    float *float_image;
//    /* float 3-component */
//    float (*float3_image)[3];
//    /* float 4-component */
//    float (*float4_image)[4];
//
//    /* Phase One black level data; */
//    short (*ph1_cblack)[2];
//    short (*ph1_rblack)[2];
//    /* save color and sizes here, too.... */
//    libraw_iparams_t iparams;
//    libraw_image_sizes_t sizes;
//    libraw_internal_output_params_t ioparams;
//    libraw_colordata_t color;
//  } libraw_rawdata_t;
//
//   /* really allocated bitmap */
public Pointer raw_alloc;
//    /* alias to single_channel variant */
public Pointer raw_image;
//    /* alias to 4-channel variant */
public Pointer color4_image;
//    /* alias to 3-color variand decoded by RawSpeed */
public Pointer color3_image;
//    /* float bayer */
public Pointer float_image;
//    /* float 3-component */
public Pointer float3_image;
//    /* float 4-component */
public Pointer float4_image;
//
//    /* Phase One black level data; */
public Pointer ph1_cblack;
public Pointer ph1_rblack;
//    /* save color and sizes here, too.... */
public LibRawIParams iparams; //libraw_iparams_t iparams;
public  LibRawImageSizes sizes;
public  LibRawInternalOutputParams  ioparams;
public  LibRawColorData color;
   
}
