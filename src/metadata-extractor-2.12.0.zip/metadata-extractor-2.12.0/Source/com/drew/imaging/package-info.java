/**
 * Contains classes for working with image file formats and photographic conversions.
 * <!-- Put @see and @since tags down here. -->
 */
package com.drew.imaging;
