/**
 * Contains classes for the extraction and modelling of JFXX (JFIF extension) metadata.
 */
package com.drew.metadata.jfxx;
