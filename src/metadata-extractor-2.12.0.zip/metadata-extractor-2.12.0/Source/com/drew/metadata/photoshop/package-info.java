/**
 * Contains classes for the extraction and modelling of Photoshop metadata.
 */
package com.drew.metadata.photoshop;
