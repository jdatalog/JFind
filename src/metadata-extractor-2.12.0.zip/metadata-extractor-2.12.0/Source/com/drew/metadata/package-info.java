/**
 * Provides classes for generic modelling of metadata directories and tags.
 * <p />
 * Contains base types for metadata processing abstraction.
 */
package com.drew.metadata;
