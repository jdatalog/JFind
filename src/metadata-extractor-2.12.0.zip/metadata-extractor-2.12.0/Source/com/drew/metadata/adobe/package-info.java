/**
 * Contains classes for the extraction and modelling of Adobe metadata.
 */
package com.drew.metadata.adobe;
