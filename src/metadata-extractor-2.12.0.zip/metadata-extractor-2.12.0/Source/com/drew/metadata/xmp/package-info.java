/**
 * Contains classes for the extraction and modelling of Adobe's XMP metadata.
 */
package com.drew.metadata.xmp;
