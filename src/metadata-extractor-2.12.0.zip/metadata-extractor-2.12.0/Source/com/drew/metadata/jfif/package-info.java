/**
 * Contains classes for the extraction and modelling of JFIF metadata.
 */
package com.drew.metadata.jfif;
