/**
 * Contains classes used internally by the library, that should not be used in client code and is not included in
 * distributions.
 */
package com.drew.tools;
